<h1><?php echo get_field('title') ?></h1>
<img class="d-inline-block pattern-lead" src="/app/themes/julien/blocs/assets/pattern.png">
<div class="col-md-4 d-inline-block page-lead">
    <?php echo get_field('lead') ?>
</div>


<div class="review-number mb-0"><?php echo get_field('number'); ?></div>
<div class="review-stars mb-1">
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
</div>
<div class="review-text mb-1"><?php echo get_field('text_1'); ?></div>
<div class="review-text"><?php echo get_field('text_2'); ?></div>
</span>